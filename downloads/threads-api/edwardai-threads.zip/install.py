#!/usr/bin/env python3
"""Install only the two public skill files; credentials are never bundled."""
import argparse
import datetime
from pathlib import Path
import shutil

FILES = ['SKILL.md', 'scripts/threads.py']

def install(source, destination):
    for name in FILES:
        if not (source/name).is_file(): raise ValueError('Incomplete package: '+name)
    if destination.exists() or destination.is_symlink():
        backup = destination.with_name(destination.name+'.backup-'+datetime.datetime.now().strftime('%Y%m%d%H%M%S%f'))
        destination.rename(backup)
    destination.mkdir(parents=True)
    for name in FILES:
        target=destination/name;target.parent.mkdir(parents=True,exist_ok=True)
        shutil.copyfile(source/name,target)
        if target.read_bytes()!=(source/name).read_bytes():raise RuntimeError('Read-back mismatch')
    return destination

if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--target',choices=['codex','claude'],required=True)
    parser.add_argument('--destination',type=Path,help='Optional explicit skill folder for isolated verification')
    args=parser.parse_args()
    folder=args.destination or Path.home()/('.codex' if args.target=='codex' else '.claude')/'skills/edwardai-threads'
    print(install(Path(__file__).resolve().parent/'skill',folder))
    print('Installed edwardai-threads; restart your AI session to discover it. API account is not connected by installation.')
